import React, { useEffect, useState } from 'react'
import { Routes, Route, BrowserRouter, NavLink, Navigate } from 'react-router-dom'
import { Listado } from '../componentes/Listado';
import { Series } from '../componentes/Series'
import { Contacto } from '../componentes/Contacto'
import { AcercaDe } from '../componentes/AcercaDe';



export const RouterPrincipal = () => {
    const [listadoState, setListadoState] = useState([]);
    useEffect(() => {
        //getMovies
        conseguirPeliculas();
        console.log("Componente cargado")
    }, [])

    const conseguirPeliculas = () => {
        let movies = JSON.parse(localStorage.getItem("Movies"));
        console.log(movies);
        setListadoState(movies);
        return movies;
    }
    return (
        <BrowserRouter>
        
            <nav className='nav'>
                <ul>
                    <li><NavLink to="/inicio" className={({ isActive }) => isActive ? "activado" : ""}>Inicio</NavLink></li>
                    <li><NavLink to="/series" className={({ isActive }) => isActive ? "activado" : ""}>Series</NavLink></li>
                    <li><NavLink to="/about" className={({ isActive }) => isActive ? "activado" : ""}>About Fly</NavLink></li>
                    <li><NavLink to="/contacto" className={({ isActive }) => isActive ? "activado" : ""}>Contacto</NavLink></li>
                </ul>
            </nav>

            <section className='content'>
                <Routes>
                    <Route path="/inicio" element={<Listado listadoState={listadoState}
                        setListadoState={setListadoState} />} />
                    <Route path="/series" element={<Series />} />
                    <Route path="/about" element={<AcercaDe />} />
                    <Route path="/contacto" element={< Contacto/>} />
                    

                </Routes>
                <aside className="lateral">
        
                </aside>
            </section>
        </BrowserRouter>


    )
}
