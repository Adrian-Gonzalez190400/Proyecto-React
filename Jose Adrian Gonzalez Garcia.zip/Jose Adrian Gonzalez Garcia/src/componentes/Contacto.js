
import React from 'react'
import { Route } from 'react-router-dom'
import image from "../files/face.png";
import image2 from "../files/instagram.png";

export const Contacto = () => {
  return (
    <div>
        <h1>Puedes contactarnos a traves de la siguiente info:</h1>
        <h2>Correo Electronico: </h2>
        <h3>s19120195@alumnos.itsur.edu.mx</h3>

        <h2>Numero de Telefono: </h2>
        <h3>4171029442</h3>

        <h2>Direccion: </h2>
        <h3>H. Galeana #175, Acambaro, Gto. Mexico</h3>
        <a href="https://www.facebook.com/joseadrian.gonzalezgarcia/" target="_blank" rel="noopener noreferrer">
            <img src={image} alt="facebook" width="50px" height="50px" ></img>
        </a>  
        <a href="https://www.instagram.com/adrian190400/" target="_blank" rel="noopener noreferrer">
            <img src={image2} alt="instagram" width="50px" height="50px" ></img>
        </a>

    </div>
  )
}
