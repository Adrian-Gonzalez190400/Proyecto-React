import React, { useEffect, useState } from 'react'
import { Listado } from './Listado';

export const Inicio = () => {

    const [listadoState, setListadoState] = useState([]);
    useEffect(() => {
        conseguirPeliculas();
        console.log("Componente cargado")
    }, []);

    const conseguirPeliculas = () => {
        let movies = JSON.parse(localStorage.getItem("Movies"));
        console.log(movies);
        setListadoState(movies);
        return movies;
    }
    return (
        <div className="App">
            <div className="layout">
                <Listado listadoState={listadoState}
                    setListadoState={setListadoState}
                />
            </div>
        </div>
    )
}
