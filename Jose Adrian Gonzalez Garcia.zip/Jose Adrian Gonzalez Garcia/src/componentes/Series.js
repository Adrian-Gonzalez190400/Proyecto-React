import React, { useEffect } from 'react'
import image from "../files/sorry.jpg";


export const Series = () => {

  return (
    <div>
        <img src={image}/><br/><br/>
        <h1>Lo Sentimos, Aun no tenemos series disponibles</h1>
    </div>
  )
}
