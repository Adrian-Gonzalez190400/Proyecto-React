import React, { useContext } from 'react'
import { FuncionContexto } from '../contexto/FuncionContexto';
import image from "../files/movie.jpg";

export const AcercaDe = () => {
    const saludo = useContext(FuncionContexto);
   

  return (
    <div>
        <h1>Fly Movies: Propiedad de {saludo}</h1>
        <h2>EL MEJOR SITIO WEB DE PELICULAS</h2>
        <h3>En Fly Movies, queremos entretener al mundo. Más allá de tus gustos y del lugar donde vivas, 
            te damos acceso a series, documentales, películas y juegos móviles de primer nivel. 
            Nuestros miembros controlan qué quieren ver y cuándo quieren verlo, sin publicidad. 
            SOfrecemos contenido por streaming en más de 30 idiomas y 
            a más de 190 países, porque las grandes historias pueden venir de cualquier lugar y 
            cautivar al público de todas partes. Nada nos apasiona más que el entretenimiento, y 
            queremos estar ahí siempre para ayudarte a encontrar tu próxima historia favorita.</h3>

        <img src={image}/>

    </div>
  )
}
