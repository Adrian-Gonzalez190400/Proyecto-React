import './App.css';
import { Listado } from './componentes/Listado';
import { Buscador } from './componentes/Buscador';
import { Agregar } from './componentes/Agregar';
import { useState,useEffect } from 'react'
import { RouterPrincipal } from './rutas/RouterPrincipal';
import { FuncionContexto } from './contexto/FuncionContexto';

function App() {
  
    const [listadoState, setListadoState] = useState([]);
  useEffect(() => {
    conseguirPeliculas();
    console.log("Componente cargado")
}, []);

const conseguirPeliculas = () => {
    let movies = JSON.parse(localStorage.getItem("Movies"));
    console.log(movies);
    setListadoState(movies);
    return movies;
}

const funcion = () =>{
    alert("Fly Movies. La Mejor Opcion Para Ver Peliculas");
  }
  return (
    
    <div className="App">
       <div className="layout">
        {/*Cabecera*/}
        <header className="header">
            <div className="logo">
                <div className="play"></div>
            </div>
            
            <h1>Fly Movies</h1>
        </header>

        {/*Router*/}
        

        {/*Contenido principal*/}
        
        <Listado listadoState={listadoState}
                setListadoState={setListadoState}
                                />
       <RouterPrincipal/>
       <FuncionContexto.Provider value={85}>
        </FuncionContexto.Provider>

        {/*Barra lateral*/}
        <aside className="lateral">
        <Buscador
            listadoState={listadoState}
            setListadoState={setListadoState}
            />
        <Agregar 
                setListadoState={setListadoState}
              />



        </aside>

        {/*Pie de página*/}
        <footer className="footer">
            &copy; Primer Proyecto - <a href="www.google.com">Adrian Gonzalez 2022 Todos los derechos reservados</a>
        </footer>

    </div>
    </div>
  );
}

export default App;
